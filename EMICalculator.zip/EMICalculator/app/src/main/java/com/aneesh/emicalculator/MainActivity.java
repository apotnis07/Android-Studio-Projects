package com.aneesh.emicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button calc;
    EditText principal,rate,years;
    TextView emi,interest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calc = findViewById(R.id.calc);
        principal = findViewById(R.id.principal);
        rate = findViewById(R.id.rate);
        years = findViewById(R.id.years);
        emi = findViewById(R.id.emi);
        interest = findViewById(R.id.interest);

        emi.setVisibility(View.GONE);
        interest.setVisibility(View.GONE);

        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sum = principal.getText().toString().trim();
                String int_rate = rate.getText().toString().trim();
                String yrs = years.getText().toString().trim();


                int sum1 = Integer.parseInt(sum);
                int int_rate2 = Integer.parseInt(int_rate);
                int yrs1 = Integer.parseInt(yrs);

                double int_rate1 = int_rate2/1200.0;
                double x = Math.pow(1+int_rate1,yrs1*12);
                double y = x - 1;
                double emi_final = (sum1*int_rate1*x)/y;

                double res = (emi_final*yrs1*12) - sum1;

                String text = "The emi is " + (int)emi_final + " rupees";
                String text1 = "The total interest is " + (int)res + " rupees";

                emi.setText(text);
                interest.setText(text1);

                emi.setVisibility(View.VISIBLE);
                interest.setVisibility(View.VISIBLE);

            }
        });
    }
}
